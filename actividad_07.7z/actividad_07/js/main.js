
document.addEventListener("DOMContentLoaded", function() {
    
    console.log("Contenido del DOM cargado");

    // Inicializar el contenido del textarea
    document.getElementById("origen").value = "<p>Este contenido <strong>está listo</strong><br>para ser editado y pasarlo abajo.</p>";

    // agrupo los inputs 
    let inputs = document.getElementsByTagName("input");
    
    // Habilitar todos los inputs
    for (let input of inputs) {
        input.disabled = false;
    }
    
    // Habilito el button
    document.querySelector("button").disabled = false;

    // mediante el evento click hago que el contenido origen se pase al destino
    document.getElementById("btn-reemplazar").addEventListener("click", function(){

        // meto en la variable el contenido del textarea 
        let texto = document.getElementById("origen").value;
        document.getElementById("destino").innerHTML = texto;
    });

    document.querySelectorAll(".btn-agregar").forEach((boton, index) => {
        boton.addEventListener("click", function() {
            if(index===0){
                // BOTON AGREGAR UNA VEZ
                let texto = document.getElementById("origen").value;
                document.getElementById("destino").innerHTML += texto;

            }else if(index===1){
                // BOTON AGREGAR 5 VECES
                let textoA = document.getElementById("origen").value;
                for(let i=0; i<5; i++){
                    document.getElementById("destino").innerHTML += textoA + "<br>";
                }
            }else if(index===2){
                // BOTON AGREGAR 10 VECES
                let textoB = document.getElementById("origen").value;
                for(let i=0; i<10; i++){
                    document.getElementById("destino").innerHTML += textoB + "<br>";
                }
            }else if(index === 3){
                // BOTON AGREGAR N VECES
                let textoC = document.getElementById("origen").value;
                let nVeces = parseInt(prompt("¿Cuántas veces quieres agregar el texto?"));

                // Validar que el número sea un entero positivo
                if (isNaN(nVeces) || nVeces <= 0) {
                    alert("Por favor, introduce un número válido mayor que 0.");
                    return;
                }

                for(let i=0; i<nVeces; i++){
                    document.getElementById("destino").innerHTML += textoC + "<br>";
                }
            }
            
        });
    });

    document.querySelector(".btn-vaciar").addEventListener("click", function() {
        document.getElementById("destino").innerHTML = "";
    });

    document.querySelector(".btn-convertir-a-mayusculas").addEventListener("click", function(){
        let textoUpper = document.getElementById("destino").innerHTML.toUpperCase();
        document.getElementById("destino").innerHTML = textoUpper;
    });

    document.querySelector("button").addEventListener("click", function(){
        let textoLower = document.getElementById("destino").innerHTML.toLowerCase();
        document.getElementById("destino").innerHTML = textoLower;
    });

    //Agregar texto a los li
    document.querySelectorAll("li").forEach((li) => {
        li.textContent = "[OK]" + li.textContent;
    });

});
